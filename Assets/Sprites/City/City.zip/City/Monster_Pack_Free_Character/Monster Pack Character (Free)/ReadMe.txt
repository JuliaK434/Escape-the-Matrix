Thank you for downloading the pack!

If you liked this pack you might be interested in my upcoming projects.

---------------------------------------------------------------------------------------
CHARACTER CREATOR
---------------------------------------------------------------------------------------

I am currently working on a character creator where you will be able to equip hundreds 
of items, it will have more animations such as more death animations, bow animations, 
staff animations, and more. The software is in development and will be accessible to 
Patrons first.

You can learn more about it here: https://www.patreon.com/posts/character-90107126


---------------------------------------------------------------------------------------
RIDDLE ZEN
---------------------------------------------------------------------------------------

I also encourage you to try my free app:
- https://play.google.com/store/apps/details?id=com.AdmurinArts.RiddleZen

In Riddle Zen you solve riddles and earn plants, it can be played offline and 
is an amazing game for all ages.


---------------------------------------------------------------------------------------
GODOT
---------------------------------------------------------------------------------------

Thank you to Coding Quests for making amazing tutorials using these assets! I highly
recommend checking his Youtube Channel if you are interested in learning Godot!

https://www.youtube.com/@Codingquests
